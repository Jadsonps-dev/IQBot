# IQ Option API

{% set donation_link = config.theme.donation_link or "#" %}

[Ajudar a manter o projeto e trazer novas features]({{ donation_link }})

Ainda não possui a tradução em portugues.

Em breve estará disponivel.

Para manter o projeto continuamente atualizado contribua com uma doação, com alguma correção ou melhoria.

As doações serão usadas para adicionar novas features.

