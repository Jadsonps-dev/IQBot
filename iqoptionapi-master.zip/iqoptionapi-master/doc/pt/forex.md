## How to trade with forex
